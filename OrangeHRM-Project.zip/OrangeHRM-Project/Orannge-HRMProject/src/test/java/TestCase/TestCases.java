package TestCase;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import BussinessLogic.Operations;
import Config.config;
import ObjectRepo.FormObjects;

public class TestCases {
	//This line is likely intended to hold a reference to a Selenium WebDriver instance for automating interactions with a Chrome browser.
			ChromeDriver driver;
			@Test(priority ='1') 
			//if you don't write throws Exception in the method signature and you still use Thread.sleep() without handling the exception locally, your code won't compile. You'll have to handle the exception in some way to make your code compile and run successfully.
			public void Login() throws Exception {
				
		        try {
		            Operations Operations = config.obj_Op;
		            Operations.openurl();
		            Thread.sleep(5000);
		            Operations.send(FormObjects.Or_Username,"Admin");
		            Thread.sleep(5000);
		            Operations.send(FormObjects.Or_Password,"admin123");
		            Thread.sleep(5000);
		            Operations.click(FormObjects.Or_Login);
		            Operations.ExtentReportTest("Login Test:To Verify login with valid credentials then user should be able to the logged In", "PASS", "Login");
		        } catch (Exception e) {
		            System.out.println(e.getMessage());
		            Operations operations = config.obj_Op;
		            operations.ExtentReportTest("Login Test:To Verify login with invalid credentials then user should not be able to logged In", "FAIL", "Issues: " + e.getMessage());
		        }
		    }
			
			@Test(priority ='2')
			
			public void NavigateToPIM_Module() throws Exception {
		        try {
		            Operations Operations = config.obj_Op;		       
		            Operations.click(FormObjects.Or_clickPIM);
		            Operations.ExtentReportTest("Navigate PIM Test:To Verify navigate PIM Module user should be able to navigate to PIM Page when click on the PIM", "PASS", "Navigate PIM");
		        } catch (Exception e) {
		            System.out.println(e.getMessage());
		            Operations operations = config.obj_Op;
		            operations.ExtentReportTest("Navigate PIM Test:To Verify navigate PIM Module user should not be able to navigate to PIM Page until do not click on the PIM", "FAIL", "Issues: " + e.getMessage());
		        }
		    }
			
            @Test(priority ='3')
			
			public void AddEmployee() throws Exception {
		        try {
		            Operations Operations = config.obj_Op;
		            Operations.click(FormObjects.Or_clickAddEmp);
		            Thread.sleep(5000);
		            Operations.send(FormObjects.Or_firstname,"Peter");
		            Thread.sleep(5000);
		            Operations.send(FormObjects.Or_middlename,"Mac");
		            Thread.sleep(5000);
		            Operations.send(FormObjects.Or_lastname,"Anderson");
		            Thread.sleep(5000);
		            Operations.send(FormObjects.Or_empId,"0423");
		            Thread.sleep(5000);
		            Operations.click(FormObjects.Or_save);
		            Operations.ExtentReportTest("Add Employee Test:To Verify add employee when fills all the details then employee should be added", "PASS", "Add Emplyee");
		        } catch (Exception e) {
		            System.out.println(e.getMessage());
		            Operations operations = config.obj_Op;
		            operations.ExtentReportTest("Add Employee Test:To Verify add employee when do not fill all the details then employee should not be added", "FAIL", "Issues: " + e.getMessage());
		        }
		    }
            
            
            @Test(priority ='4')
			
			public void SearchEmployee() throws Exception {
		        try {
		            Operations Operations = config.obj_Op;
		            Operations.click(FormObjects.Or_clickEmpList);
		            Thread.sleep(5000);
		            Operations.send(FormObjects.Or_SearchEmpName,"Peter");
		            Thread.sleep(5000);
		            Operations.click(FormObjects.Or_ClickPeter);
		            Thread.sleep(5000);
		            Operations.click(FormObjects.Or_Search);
		            Operations.SCROLLBY(400);
		            Operations.ExtentReportTest("Seach Employee Test:To Verify search employee when search the valid employee name then it should be able to displayed in record list ", "PASS", "Search Emplyee");
		        } catch (Exception e) {
		            System.out.println(e.getMessage());
		            Operations operations = config.obj_Op;
		            operations.ExtentReportTest("Seach Employee Test:To Verify search employee when search the invalid employee name then it should not be able to displayed in record list", "FAIL", "Issues: " + e.getMessage());
		        }
		    }


            
            @Test(priority ='5')
			
			public void EditEmployee() throws Exception {
		        try {
		            Operations Operations = config.obj_Op;
		            Operations.click(FormObjects.Or_clickEdit);
		            Thread.sleep(5000);
		            Operations.click(FormObjects.Or_ClickJob);
		            Thread.sleep(5000);
		            Operations.click(FormObjects.ClickJoiningDate);
		            Thread.sleep(5000);
		            Operations.click(FormObjects.Or_ClickYear);
		            Thread.sleep(5000);
		            Operations.click(FormObjects.Or_SelectYear);
		            Thread.sleep(5000);
		            Operations.click(FormObjects.Or_Selectdate);
	                Thread.sleep(5000);
		            Operations.click(FormObjects.Or_ClickJobTitle);
		            Thread.sleep(5000);
		            Operations.click(FormObjects.Or_SelectJobTitle);
		            Thread.sleep(5000);
		            Operations.click(FormObjects.Or_ClickJobCategory);
		            Thread.sleep(5000);
		            Operations.click(FormObjects.Or_SelectJobCategory);
		            Thread.sleep(5000);
		            Operations.click(FormObjects.Or_ClickSubUnit);
		            Thread.sleep(5000);
		            Operations.click(FormObjects.Or_SelectSubUnit);
		            Thread.sleep(5000);
		            Operations.click(FormObjects.Or_ClickLoction);
		            Thread.sleep(5000);
		            Operations.click(FormObjects.Or_SelectLocation);
		            Thread.sleep(5000);
		            Operations.click(FormObjects.Or_ClickEmpStatus);
		            Thread.sleep(5000);
		            Operations.click(FormObjects.Or_SelectEmpStatus);
		            Thread.sleep(5000);
		            Operations.click(FormObjects.Or_Save1);
		       //     Operations.SCROLLBY(400);
		            Operations.ExtentReportTest("Edit Employee Test:To Verify edit employee when edit the employee with save button then it should be able to edit the employee", "PASS", "Edit Employee");
		        } catch (Exception e) {
		            System.out.println(e.getMessage());
		            Operations operations = config.obj_Op;
		            operations.ExtentReportTest("Edit Employee Test:To Verify edit employee when edit the employee with do not click on save button then it should not be able to edit", "FAIL", "Issues: " + e.getMessage());
		        		    }
			
		    }

            
//            @Test(priority ='6')
//			
//			public void DeleteEmployee() throws Exception {
//		        try {
//		            Operations Operations = config.obj_Op;
//		            Operations.click(FormObjects.Or_clickEmpList1);
//		            Thread.sleep(5000);
//		            Operations.send(FormObjects.Or_SearchEmpName1,"Peter");
//		            Thread.sleep(5000);
//		            Operations.click(FormObjects.Or_ClickPeterMac1);
//		            Thread.sleep(5000);
//		            Operations.click(FormObjects.Or_Search1);
//		            Thread.sleep(5000);
//		            Operations.SCROLLBY(400);
//		            Thread.sleep(5000);
//		            Operations.click(FormObjects.Or_ClickDeleteIcon);
//		            Thread.sleep(5000);
//		            Operations.click(FormObjects.Or_ClickConfirmYes);
//		            Operations.ExtentReportTest("Delete Employee Test:To Verify delete employee when delete the employee with click on delete button then it should be able to delete the employee", "PASS", "Delete Employee");
//		        } catch (Exception e) {
//		            System.out.println(e.getMessage());
//		            Operations operations = config.obj_Op;
//		            operations.ExtentReportTest("Delete Employee Test:To Verify delete employee when delete the employee with do not click on delete button then it should not be able to delete", "FAIL", "Issues: " + e.getMessage());
//		        		    }
//			
//		    }
//		    }
            @Test(priority ='7')

            public void NavigateToClaim_Module() throws Exception {
                try {
                    Operations Operations = config.obj_Op;
                    Operations.click(FormObjects.Or_clickclaim);                   
        Operations.ExtentReportTest("Navigate Claim Test:To Verify navigate claim Module user should be able to navigate to claim Page when click on the claim", "PASS", "Navigate claim");
    } catch (Exception e) {
        System.out.println(e.getMessage());
        Operations operations = config.obj_Op;
        operations.ExtentReportTest("Navigate Claim Test:To Verify navigate claim Module user should not be able to navigate to claim Page until do not click on the claim", "FAIL", "Issues: " + e.getMessage());
    		    }

}
            
            @Test(priority ='8')

            public void AssignClaim() throws Exception {
                try {
                    Operations Operations = config.obj_Op;
                    Operations.click(FormObjects.Or_ClickAddAssignClaim);
                    Thread.sleep(5000);
                    Operations.send(FormObjects.Or_SearchEmpName2,"Peter");
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_ClickPeter2);
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_ClickEvent);
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_SelectEvent);
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_ClickCurrency);
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_SelectCurrency);
                    Thread.sleep(5000);
                    Operations.send(FormObjects.Or_EnterRemark,"Ok");
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_Create);
        Operations.ExtentReportTest("AssignClaim Test:To Verify assign claim with fills all the details then user should be able to assign the claim", "PASS", "Assign claim");
    } catch (Exception e) {
        System.out.println(e.getMessage());
        Operations operations = config.obj_Op;
        operations.ExtentReportTest("AssignClaim Test:To Verify assign claim with some fields are left blank then user should not be able to assign the claim", "FAIL", "Issues: " + e.getMessage());
    		    }

}
            
            @Test(priority ='9')

            public void AddExpence() throws Exception {
                try {
                    Operations Operations = config.obj_Op;
                    Operations.SCROLLBY(200);
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_ClickAddExpense);
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_ClickExpenseType);
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_SelectExpenseType);
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_ClickDate);
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_ClickYear1);
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_SelectYear1);
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_SelectDate1);
                    Thread.sleep(5000);
                    Operations.send(FormObjects.Or_EnterAmount,"1000");
                    Thread.sleep(5000);
                    Operations.send(FormObjects.Or_EnterNote,"Yes");
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_SaveButton);
                    Operations.SCROLLBY(200);
        Operations.ExtentReportTest("AddExpense Test:To Verify add expense with fills all the details then user should be able to add the expense", "PASS", "Add Expense");
    } catch (Exception e) {
        System.out.println(e.getMessage());
        Operations operations = config.obj_Op;
        operations.ExtentReportTest("AddExpense Test:To Verify add expense with some fields are left blank then user should not be able to add the expense", "FAIL", "Issues: " + e.getMessage());
    		    }

}
            
            @Test(priority ='A')

            public void EditExpence() throws Exception {
                try {
                    Operations Operations = config.obj_Op;                                       
                    Operations.click(FormObjects.Or_ClickEditExpense);
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_EditExpenseType);
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_SelectExpenseTypeEdit);
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_ClickDateEdit);
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_ClickYearEdit);
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_SelectYearEdit);
                    Thread.sleep(5000);
                    Operations.click(FormObjects.Or_SelectDateEdit);
                    Thread.sleep(5000);     
                    Operations.click(FormObjects.Or_SaveButton1);
                    Operations.SCROLLBY(200);
        Operations.ExtentReportTest("EditExpense Test:To Verify Edit expense with click on the edit icon then user should be able to edit the expense", "PASS", "Edit Expense");
    } catch (Exception e) {
        System.out.println(e.getMessage());
        Operations operations = config.obj_Op;
        operations.ExtentReportTest("EditExpense Test:To Verify Edit expense with do not click on the edit icon then user should not be able to edit the expense", "FAIL", "Issues: " + e.getMessage());
    		    }

}
            
            @Test(priority = 'B')
            public void AddAttachment() throws Exception {
                try {
                    Operations operations = config.obj_Op;
                    
                    operations.click(FormObjects.Or_ClickAddAttachment);
                    Thread.sleep(5000);
                    
                    // Use the correct XPath for the file input element
                    Operations.imageproperty(FormObjects.Or_SelectFile);
                    Thread.sleep(5000);
                    
                    operations.send(FormObjects.Or_Comment,"ok");
                    Thread.sleep(5000);
                    
                    operations.click(FormObjects.Or_Save2);                   
                    
                    operations.ExtentReportTest("Add Attachment Test:To Verify add attachment with select the valid path then user should be able to add the attachment", "PASS", "Add Attachment");
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                    Operations operations = config.obj_Op;
                    operations.ExtentReportTest("Add Attachment Test:To Verify add attachment with does not take the valid path then user should not be able to add the attachment", "FAIL", "Issues: " + e.getMessage());
                }
            }
}













