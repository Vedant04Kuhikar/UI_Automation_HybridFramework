package ObjectRepo;

public class FormObjects {
	
	
	public static String Or_Username="//input[@placeholder='Username']";
	public static String Or_Password="//input[@placeholder='Password']";
    public static String Or_Login="//button[normalize-space()='Login']";
    public static String Or_clickPIM="//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name'][normalize-space()='PIM']";
    public static String Or_clickAddEmp="//a[normalize-space()='Add Employee']";
    public static String Or_firstname="//input[@placeholder='First Name']";
    public static String Or_middlename="//input[@placeholder='Middle Name']";
    public static String Or_lastname="//input[@placeholder='Last Name']";
    public static String Or_empId="//div[@class='oxd-input-group oxd-input-field-bottom-space']//div//input[@class='oxd-input oxd-input--active']";
    public static String Or_save="//button[normalize-space()='Save']";
    public static String Or_clickEmpList="//a[normalize-space()='Employee List']";
    public static String Or_SearchEmpName="//div[@class='oxd-grid-4 orangehrm-full-width-grid']//div[1]//div[1]//div[2]//div[1]//div[1]//input[1]";
    public static String Or_ClickPeter="//span[normalize-space()='Peter Mac Anderson']";
    public static String Or_Search="//button[normalize-space()='Search']";
    public static String Or_clickEdit="//body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[2]/div[3]/div[1]/div[2]/div[1]/div[1]/div[9]/div[1]/button[2]/i[1]";
    public static String Or_ClickJob="//a[normalize-space()='Job']";
    public static String ClickJoiningDate="//input[@placeholder='yyyy-dd-mm']";
    public static String Or_ClickYear="//li[@class='oxd-calendar-selector-year']//p[1]";
    public static String Or_SelectYear="//li[normalize-space()='2021']";
    public static String Or_Selectdate="//div[contains(text(),'17')]";
    public static String Or_ClickJobTitle="//body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/i[1]";
    public static String Or_SelectJobTitle="//span[normalize-space()='Chief Technical Officer']";
    public static String Or_ClickJobCategory="//body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/div[1]/div[1]/div[4]/div[1]/div[2]/div[1]/div[1]/div[1]";
    public static String Or_SelectJobCategory="//span[normalize-space()='Officials and Managers']";
    public static String Or_ClickSubUnit="//body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/div[1]/div[1]/div[5]/div[1]/div[2]/div[1]/div[1]/div[1]";
    public static String Or_SelectSubUnit="//span[normalize-space()='Engineering']";
    public static String Or_ClickLoction="//body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/div[1]/div[1]/div[6]/div[1]/div[2]/div[1]/div[1]/div[1]";
    public static String Or_SelectLocation="//span[normalize-space()='HQ - CA, USA']";
    public static String Or_ClickEmpStatus="//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/div/div[2]/div[1]/form/div[1]/div/div[7]/div/div[2]/div/div/div[2]/i";
    public static String Or_SelectEmpStatus="//span[normalize-space()='Full-Time Permanent']";
    public static String Or_Save1="//button[normalize-space()='Save']";
    public static String Or_clickEmpList1="//a[normalize-space()='Employee List']";
    public static String Or_SearchEmpName1="//div[@class='oxd-grid-4 orangehrm-full-width-grid']//div[1]//div[1]//div[2]//div[1]//div[1]//input[1]";
    public static String Or_ClickPeterMac1="//span[normalize-space()='Peter Mac Anderson']";
    public static String Or_Search1="//button[normalize-space()='Search']";
    public static String Or_ClickDeleteIcon="//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[2]/div[3]/div/div[2]/div/div/div[9]/div/button[1]";
    public static String Or_ClickConfirmYes="//*[@id=\"app\"]/div[3]/div/div/div/div[3]/button[2]";
    public static String Or_clickclaim="//span[normalize-space()='Claim']";
    public static String Or_ClickAddAssignClaim="//button[normalize-space()='Assign Claim']";
    public static String Or_SearchEmpName2="//input[@placeholder='Type for hints...']";
    public static String Or_ClickPeter2="//span[normalize-space()='Peter Mac Anderson']";
    public static String Or_ClickEvent="//body[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/form[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]";
    public static String Or_SelectEvent="//span[normalize-space()='Travel Allowance']";
    public static String Or_ClickCurrency="//div[contains(text(),'-- Select --')]";
    public static String Or_SelectCurrency="//span[normalize-space()='Algerian Dinar']";
    public static String Or_EnterRemark="//textarea[@class='oxd-textarea oxd-textarea--active oxd-textarea--resize-vertical']";
    public static String Or_Create="//button[normalize-space()='Create']";
    public static String Or_ClickAddExpense="//div[@class='oxd-layout-context']//div[2]//div[1]//button[1]";
    public static String Or_ClickExpenseType="//div[@class='oxd-select-text-input']";
    public static String Or_SelectExpenseType="//span[normalize-space()='Transport']";
    public static String Or_ClickDate="input[placeholder='dd-mm-yyyy']";
    public static String Or_ClickYear1="//div[@class='oxd-calendar-selector-year-selected']//i[@class='oxd-icon bi-caret-down-fill oxd-icon-button__icon']";
    public static String Or_SelectYear1="//li[normalize-space()='2020']";
    public static String Or_SelectDate1="//div[contains(text(),'20')]";
    public static String Or_EnterAmount="//div[@class='oxd-grid-2 orangehrm-full-width-grid']//div[@class='oxd-grid-item oxd-grid-item--gutters']//div[@class='oxd-input-group oxd-input-field-bottom-space']//div//input[@class='oxd-input oxd-input--active']";
    public static String Or_EnterNote="//div[@class='oxd-grid-1 orangehrm-full-width-grid']//div[@class='oxd-grid-item oxd-grid-item--gutters']//div[@class='oxd-input-group oxd-input-field-bottom-space']//div//textarea[@class='oxd-textarea oxd-textarea--active oxd-textarea--resize-vertical']";
    public static String Or_SaveButton="//button[normalize-space()='Save']";
    public static String Or_ClickEditExpense="//i[@class='oxd-icon bi-pencil-fill']";
    public static String Or_EditExpenseType="//div[@class='oxd-select-text-input']";
    public static String Or_SelectExpenseTypeEdit="//span[normalize-space()='Planned Surgery']";
    public static String Or_ClickDateEdit="input[placeholder='dd-mm-yyyy']";
    public static String Or_ClickYearEdit="//div[@class='oxd-calendar-selector-year-selected']//i[@class='oxd-icon bi-caret-down-fill oxd-icon-button__icon']";
    public static String Or_SelectYearEdit="//li[normalize-space()='2022']";
    public static String Or_SelectDateEdit="//div[@class='oxd-calendar-date'][normalize-space()='4']";
    public static String Or_SaveButton1="//button[normalize-space()='Save']";
    public static String Or_ClickAddAttachment="//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/div[6]/div/button";
    public static String Or_SelectFile="//div[@class='oxd-file-div oxd-file-div--active']";
    public static String Or_Comment="//textarea[@placeholder='Type comment here']";
    public static String Or_Save2="//button[normalize-space()='Save']";
    
    
    
}





