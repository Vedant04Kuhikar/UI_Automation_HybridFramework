package BussinessLogic;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.apache.commons.io.FileUtils;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


public class Operations {
	public static WebDriver driver;
	private static ExtentReports report;
    
	static {
		// Initialize ExtentReports with the path for the HTML report
        report = new ExtentReports(System.getProperty("user.dir") + "//HTMLReports//ExtentReportsResults" + System.currentTimeMillis() + ".html");
    }
	
	
	
	

    public void openurl() throws InterruptedException {
        String v1 = System.getProperty("user.dir");
        System.out.println("directory = " + v1);
        System.setProperty("webdriver.chrome.driver", v1 + "/Drivers/chromedriver.exe");
        ChromeOptions co = new ChromeOptions();
        co.addArguments("--remote-allow-origins=*");
        driver = new ChromeDriver(co);

        driver.manage().window().maximize();
        driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
        Thread.sleep(1000);
    }
    
    public void send (String xpath, String KEYS) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
		driver.findElement(By.xpath(xpath)).sendKeys(KEYS);
}
    public void click(String xpath) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
		driver.findElement(By.xpath(xpath)).click();
    }
    public void selectDropdownByVisibleText(By dropdownLocator, String text) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        WebElement dropdownElement = wait.until(ExpectedConditions.visibilityOfElementLocated(dropdownLocator));
        Select dropdown = new Select(dropdownElement);
        dropdown.selectByVisibleText(text);
}
    public void selectDropdownByIndex(By dropdownLocator, int index) {
	    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	    WebElement dropdownElement = wait.until(ExpectedConditions.visibilityOfElementLocated(dropdownLocator));
    
	    Select dropdown = new Select(dropdownElement);
	    dropdown.selectByIndex(index);
}
      public static String capture(WebDriver driver) throws IOException {
          File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
          File dest = new File(System.getProperty("user.dir") + "//Screenshot//IMAGE" + System.currentTimeMillis() + ".png");
          String filePath = dest.getAbsolutePath();
          FileUtils.copyFile(scrFile, dest);
          return filePath;
      }
   
      public void ExtentReportTest(String TestCase, String status, String Testdetails) throws IOException {
          // Reuse the ExtentTest object
          ExtentTest test = report.startTest(TestCase);
          
          if (status.equalsIgnoreCase("PASS")) {
              test.log(LogStatus.PASS, test.addScreenCapture(capture(driver)) + Testdetails);
          } else {                                                                          
              test.log(LogStatus.FAIL, test.addScreenCapture(capture(driver)) + Testdetails);
          }
           
          report.flush(); // Flush the report after each test case
 }
    
    public void navigateToURL(WebDriver driver, String url) {
        driver.get(url);
    }
    public void SCROLLBY(int px) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,"+px+")", "");
}
    public static void imageproperty(String xpath) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(100));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
                    
        String v1 = System.getProperty("user.dir");
        System.out.println(v1);
        String ImageURL = v1 + "\\1714728606275.jpg";
        
        // Send the image file path to the file input element
        WebElement fileInput = driver.findElement(By.xpath(xpath));
        fileInput.sendKeys(ImageURL);
    }
}




