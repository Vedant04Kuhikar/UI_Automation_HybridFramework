package Config;

import BussinessLogic.Operations;

public class config {
	public static Operations obj_Op= new Operations();

}
