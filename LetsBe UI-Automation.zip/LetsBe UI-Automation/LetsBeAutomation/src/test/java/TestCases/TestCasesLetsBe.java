package TestCases;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import BussinessLogic.Operations;
import Config.config;
import ObjectRepo.*;
public class TestCasesLetsBe {
	ChromeDriver driver;
	@Test(priority ='1')
	public void LoginLogsPage() throws Exception {
        try {
            Operations Operations = config.obj_Op;
            Operations.openurl();
            Operations.ExtentReportTest("Login Logs Test:To Verify user should be able to access login logs page with valid URL", "PASS", "Login Logs Page");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Operations operations = config.obj_Op;
            operations.ExtentReportTest("Login Logs Test:To Verify user should not be able to access logs page with invalid URL", "FAIL", "Issues: " + e.getMessage());
        }
    }
	
	@Test(priority ='2')
	public void LoginPage() throws Exception {
        try {
            Operations Operations = config.obj_Op;
            Thread.sleep(5000);
            Operations.click(FormObjects.Or_Admin);
         
            Operations.ExtentReportTest("Login Page Test:To Verify after clicking on the admin user it should be able to access login page", "PASS", "Login Page");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            Operations operations = config.obj_Op;
            operations.ExtentReportTest("Login Page Test:To Verify if we don't click on admin user then it should not be able to access logs page with invalid URL", "FAIL", "Issues: " + e.getMessage());
	
}
	}
}














	