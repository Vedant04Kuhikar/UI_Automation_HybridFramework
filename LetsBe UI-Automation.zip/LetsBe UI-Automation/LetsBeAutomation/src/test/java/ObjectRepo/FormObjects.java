package ObjectRepo;

public class FormObjects {

	public static String Or_Admin="//div[2]//div[1]//div[1]//h5[1]//*[name()='svg']";
	
	
	
	
}
